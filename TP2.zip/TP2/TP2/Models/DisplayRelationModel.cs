﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorDemoUI.Models
{
    public class DisplayRelationModel
    {
        [Required]
        public int Ref_film { get; set; }

        [Required]
        public int Ref_realisateur { get; set; }
    }
}

