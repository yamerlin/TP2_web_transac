﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class RealisateurModel
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public int ID { get; set; }
    }
}
