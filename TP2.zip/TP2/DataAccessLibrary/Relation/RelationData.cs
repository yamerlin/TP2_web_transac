﻿using DataAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public class RelationData : IRelationData
    {
        private readonly ISqlDataAccess _db;

        public RelationData(ISqlDataAccess db)
        {
            _db = db;
        }

        public Task<List<RelationModel>> GetRelation()
        {
            string sql = "select * from dbo.Cinematheque";

            return _db.LoadData<RelationModel, dynamic>(sql, new { });
        }

        public Task InsertRelation(RelationModel relation)
        {
            string sql = @"insert into dbo.Cinematheque (Ref_film, Ref_realisateur)
                           values (@Ref_film, @Ref_realisateur);";

            return _db.SaveData(sql, relation);
        }
    }
}
