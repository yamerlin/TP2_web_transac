﻿using DataAccessLibrary.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public interface IFilmData
    {
        Task<List<FilmModel>> GetFilm();
        Task InsertFilm(FilmModel film);
    }
}