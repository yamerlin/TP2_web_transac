﻿using DataAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public class FilmData : IFilmData
    {
        private readonly ISqlDataAccess _db;

        public FilmData(ISqlDataAccess db)
        {
            _db = db;
        }

        public Task<List<FilmModel>> GetFilm()
        {
            string sql = "select * from dbo.Film";

            return _db.LoadData<FilmModel, dynamic>(sql, new { });
        }

        public Task InsertFilm(FilmModel film)
        {
            string sql = @"insert into dbo.Film (Titre, ID)
                           values (@Titre, @ID);";

            return _db.SaveData(sql, film);
        }
    }
}
