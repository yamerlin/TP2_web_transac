﻿using DataAccessLibrary.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public interface IRealisateurData
    {
        Task<List<RealisateurModel>> GetRealisateur();
        Task InsertRealisateur(RealisateurModel realisateur);
    }
}