﻿using DataAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public class RealisateurData : IRealisateurData
    {
        private readonly ISqlDataAccess _db;

        public RealisateurData(ISqlDataAccess db)
        {
            _db = db;
        }

        public Task<List<RealisateurModel>> GetRealisateur()
        {
            string sql = "select * from dbo.Realisateur";

            return _db.LoadData<RealisateurModel, dynamic>(sql, new { });
        }

        public Task InsertRealisateur(RealisateurModel realisateur)
        {
            string sql = @"insert into dbo.Realisateur (Nom, Prenom, ID)
                           values (@Nom, @Prenom, @ID);";

            return _db.SaveData(sql, realisateur);
        }
    }
}
