﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary.Models
{
    public class AffichageRelationModel
    {
        public string Titre {get ; set;}
        public string Nom { get; set; }
    }
}
