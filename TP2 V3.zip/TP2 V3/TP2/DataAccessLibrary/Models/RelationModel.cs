﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class RelationModel
    {
        public int Ref_film { get; set; }
        public int Ref_realisateur { get; set; }
    }
}
