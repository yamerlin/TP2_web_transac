﻿using DataAccessLibrary.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public interface IFilmData
    {
        Task<List<FilmModel>> GetFilm();
        int GetID(string Titre);
        void DeleteFilm(int id);
        void DeleteRelation(int id);
        Task InsertFilm(FilmModel film);
    }
}