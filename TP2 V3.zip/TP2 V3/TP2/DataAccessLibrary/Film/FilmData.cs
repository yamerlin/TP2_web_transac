﻿using DataAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLibrary
{
    public class FilmData : IFilmData
    {
        private readonly ISqlDataAccess _db;

        public FilmData(ISqlDataAccess db)
        {
            _db = db;
        }

        public Task<List<FilmModel>> GetFilm()
        {
            string sql = "select * from dbo.Film";

            return _db.LoadData<FilmModel, dynamic>(sql, new { });
        }

        public int GetID(string Titre)
        {
            int id;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select ID from dbo.Film where Titre = @Titre";
                    cmd.Parameters.Add("@Titre", SqlDbType.VarChar).Value = Titre;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        id = Convert.ToInt32(dt.Rows[0]["ID"]);
                    }
                }
            }

            return id;
        }

        public void DeleteRelation(int id)
        {
            string sql = @"delete from dbo.Cinematheque where Ref_film=@id";

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                    }
                }
            }
        }

        public void DeleteFilm(int id)
        {
            string sql = @"delete from dbo.Film where Id=@id";

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                    }
                }
            }
        }

        public Task InsertFilm(FilmModel film)
        {
            string sql = @"insert into dbo.Film (Titre)
                           values (@Titre);";

            return _db.SaveData(sql, film);
        }
    }
}
