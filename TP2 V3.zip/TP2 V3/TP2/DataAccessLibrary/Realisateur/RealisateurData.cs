﻿using DataAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLibrary
{
    public class RealisateurData : IRealisateurData
    {
        private readonly ISqlDataAccess _db;

        public RealisateurData(ISqlDataAccess db)
        {
            _db = db;
        }

        public Task<List<RealisateurModel>> GetRealisateur()
        {
            string sql = "select Prenom, Nom, ID from dbo.Realisateur";

            return _db.LoadData<RealisateurModel, dynamic>(sql, new { });
        }

        public int GetID(string Nom)
        {
            int id;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "select ID from dbo.Realisateur where Nom = @Nom";
                    cmd.Parameters.Add("@Nom", SqlDbType.VarChar).Value = Nom;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        id = Convert.ToInt32(dt.Rows[0]["ID"]);
                    }
                }
            }

            return id;
        }

        public Task InsertRealisateur(RealisateurModel realisateur)
        {
            string sql = @"insert into dbo.Realisateur (Nom, Prenom)
                           values (@Nom, @Prenom);";

            return _db.SaveData(sql, realisateur);
        }

        public int GetRealisateurId(string nom)
        {
            int id;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Id FROM dbo.Realisateur WHERE Nom = @nom";
                    cmd.Parameters.Add("@nom", SqlDbType.VarChar).Value = nom;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        id = Convert.ToInt32(dt.Rows[0]["Id"]);
                    }
                }
            }

            return id;
        }

        public void DeleteRelation(int realisateurIndex)
        {
            string sql = @"delete from dbo.Cinematheque where Ref_realisateur=@realisateurIndex";

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.Add("@realisateurIndex", SqlDbType.Int).Value = realisateurIndex;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                    }
                }
            }
        }


        public void DeleteRealisateur(int id)
        {
            string sql = @"delete from dbo.Realisateur where Id=@id";

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                    }
                }
            }
        }

    }
}
