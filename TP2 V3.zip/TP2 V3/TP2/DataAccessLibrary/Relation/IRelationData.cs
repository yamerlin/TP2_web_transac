﻿using DataAccessLibrary.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public interface IRelationData
    {
        Task<List<RelationModel>> GetRelation();
        Task<List<SelectRealisateurModel>> GetRealisateurNom();
        Task<List<SelectFilmModel>> GetFilmTitre();
        Task<List<AffichageRelationModel>> GetRelationAAfficher();
        string GetRealisateurFromId(int id);
        string GetFilmFromId(int id);
        string GetLastRealisateur();
        string GetLastFilm(); 
        int GetRealisateurId(string nom);
        int GetFilmId(string titre);
        Task InsertRelation(RelationModel relation);
        void DeleteRelation(int indexRealisateur, int indexFilm);
    }
}