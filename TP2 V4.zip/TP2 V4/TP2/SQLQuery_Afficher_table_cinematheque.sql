﻿/*Relier les trois tables pour afficher le film autant de fois qu'il a de réalisteur et remplacer les ID par les nom
de films et de réalisateur*/

Select Titre, Nom as "Nom du Réalisateur", Prenom as "Prenom du réalisateur" from dbo.Cinematheque
Inner Join dbo.Film on dbo.Film.Id = dbo.Cinematheque.Ref_film
Inner Join dbo.Realisateur on dbo.Realisateur.Id = dbo.Cinematheque.Ref_realisateur

