CREATE TABLE [dbo].[Film] (
    [Id]    INT identity (1,1) NOT NULL,
    [Titre] VARCHAR (100) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Realisateur] (
    [Id]     INT identity (1,1) NOT NULL,
    [Nom]    VARCHAR (100) NOT NULL,
    [Prenom] VARCHAR (100) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


CREATE TABLE [dbo].[Cinematheque] (
    [Ref_film]        INT NULL,
    [Ref_realisateur] INT NULL,
    FOREIGN KEY ([Ref_film]) REFERENCES [dbo].[Film] ([Id]),
    FOREIGN KEY ([Ref_realisateur]) REFERENCES [dbo].[Realisateur] ([Id])
);