﻿using DataAccessLibrary.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public interface IRealisateurData
    {
        Task<List<RealisateurModel>> GetRealisateur();
        int GetID(string Nom);
        Task InsertRealisateur(RealisateurModel realisateur);
        void DeleteRealisateur(int id);
        void DeleteRelation(int realisateurIndex);
        int GetRealisateurId(string nom);
    }
}