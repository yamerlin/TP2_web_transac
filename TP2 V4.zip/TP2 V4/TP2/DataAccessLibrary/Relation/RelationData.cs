﻿using DataAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary
{
    public class RelationData : IRelationData
    {
        private readonly ISqlDataAccess _db;

        public RelationData(ISqlDataAccess db)
        {
            _db = db;
        }

        public Task<List<RelationModel>> GetRelation()
        {
            string sql = "select * from dbo.Cinematheque";

            return _db.LoadData<RelationModel, dynamic>(sql, new { });
        }

        public Task<List<SelectRealisateurModel>> GetRealisateurNom()
        {
            string sql = "select Nom from dbo.Realisateur";

            return _db.LoadData<SelectRealisateurModel, dynamic>(sql, new { });
        }

        public Task<List<SelectFilmModel>> GetFilmTitre()
        {
            string sql = "select Titre from dbo.Film";

            return _db.LoadData<SelectFilmModel, dynamic>(sql, new { });
        }

        public Task<List<AffichageRelationModel>> GetRelationAAfficher()
        {
            string sql = "Select Titre, Nom from dbo.Cinematheque Inner Join dbo.Film on dbo.Film.Id = dbo.Cinematheque.Ref_film Inner Join dbo.Realisateur on dbo.Realisateur.Id = dbo.Cinematheque.Ref_realisateur";

            return _db.LoadData<AffichageRelationModel, dynamic>(sql, new { });
        }

        public string GetRealisateurFromId(int id)
        {
            string nomRealisateur;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Nom FROM dbo.Realisateur WHERE Id=@id";
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        nomRealisateur = Convert.ToString(dt.Rows[0]["Nom"]);
                    }
                }
            }

            return nomRealisateur;
        }

        public string GetFilmFromId(int id)
        {
            string nomFilm;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Titre FROM dbo.Film WHERE Id=@id";
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        nomFilm = Convert.ToString(dt.Rows[0]["Titre"]);
                    }
                }
            }

            return nomFilm;
        }

        public string GetLastRealisateur()
        {
            string nomDernierRealisateur;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Nom FROM dbo.Realisateur WHERE Id=(SELECT max(Id) FROM dbo.Realisateur)";
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        nomDernierRealisateur = Convert.ToString(dt.Rows[0]["Nom"]);
                    }
                }
            }

            return nomDernierRealisateur;
        }

        public string GetLastFilm()
        {
            string nomDernierFilm;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Titre FROM dbo.Film WHERE Id=(SELECT max(Id) FROM dbo.Film)";
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        nomDernierFilm = Convert.ToString(dt.Rows[0]["Titre"]);
                    }
                }
            }

            return nomDernierFilm;
        }

        public int GetRealisateurId(string nom)
        {
            int id;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Id FROM dbo.Realisateur WHERE Nom = @nom";
                    cmd.Parameters.Add("@nom", SqlDbType.VarChar).Value = nom;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        id = Convert.ToInt32(dt.Rows[0]["Id"]);
                    }
                }
            }

            return id;
        }

        public int GetFilmId(string titre)
        {
            int id;

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Id FROM dbo.Film WHERE Titre = @titre";
                    cmd.Parameters.Add("@titre", SqlDbType.VarChar).Value = titre;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                        id = Convert.ToInt32(dt.Rows[0]["Id"]);
                    }
                }
            }

            return id;
        }

        public Task InsertRelation(RelationModel relation)
        {
            string sql = @"insert into dbo.Cinematheque (Ref_film, Ref_realisateur)
                           values (@Ref_film, @Ref_realisateur);";

            return _db.SaveData(sql, relation);
        }

        public void DeleteRelation(int indexRealisateur, int indexFilm)
        {
            string sql = @"delete from dbo.Cinematheque where Ref_realisateur=@indexRealisateur AND Ref_film = @indexFilm";

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Cinematheque; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False"))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.Add("@indexRealisateur", SqlDbType.VarChar).Value = indexRealisateur;
                    cmd.Parameters.Add("@indexFilm", SqlDbType.VarChar).Value = indexFilm;
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        adp.Fill(dt);
                    }
                }
            }
        }


    }   
}
