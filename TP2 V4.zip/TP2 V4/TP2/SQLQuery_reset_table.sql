﻿DELETE FROM dbo.Realisateur
DBCC CHECKIDENT ('dbo.Realisateur', RESEED, 0);

DELETE FROM dbo.Film
DBCC CHECKIDENT ('dbo.Film', RESEED, 0);

DELETE FROM dbo.Cinematheque


